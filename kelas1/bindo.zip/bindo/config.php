<?php

$koneksi = mysql_connect("localhost","root","");
mysql_select_db("db_eforumv2",$koneksi);

?>
