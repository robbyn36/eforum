<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
body,td,th {
	font-weight: bold;
	font-style: italic;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <h1 align="center">E-Forum </h1>
  <div align="center">
    <table width="569" height="424" border="1">
      <tr>
        <th scope="col"><h2>Kelas VI</h2></th>
      </tr>
      <tr>
        <th scope="row">IPS</th>
      </tr>
      <tr>
        <th scope="row"><a href="http://127.0.0.1/forum/S2V2/kelasvi/ipa/index2ipa.php">IPA</a></th>
      </tr>
      <tr>
        <th scope="row">PKN</th>
      </tr>
      <tr>
        <th scope="row">MTK</th>
      </tr>
      <tr>
        <th scope="row">B.indonesia</th>
      </tr>
      <tr>
        <th scope="row">Ekonomi</th>
      </tr>
      <tr>
        <th scope="row">B.inggris</th>
      </tr>
      <tr>
        <th scope="row">Kebudayaan</th>
      </tr>
      <tr>
        <th scope="row">Olahraga</th>
      </tr>
      <tr>
        <th scope="row"><table width="521" height="46" border="1" align="center">
          <tr>
            <th width="61" height="40" scope="col"><div align="center"><a href="http://127.0.0.1/forum/Eforum/index/">Home</a></div></th>
            <th width="114" scope="col"><div align="center"><a href="http://127.0.0.1/forum/Eforum/buatposting.php">Posting Baru</a></div></th>
            <th width="80" scope="col"><div align="center"><a href="http://127.0.0.1/forum/Eforum/profil.php">Profil</a></div></th>
            <th width="126" scope="col"><div align="center"><a href="http://127.0.0.1/forum/Eforum/gantipass.php">Ganti Password</a></div></th>
            <th width="106" scope="col"><div align="center">Keluar</div></th>
          </tr>
        </table></th>
      </tr>
    </table>
  </div>
  <p>&nbsp;</p>
</form>
</body>
</html>